# NeXTCS Final Project
### Programmer 0: Javohir Abdurazzakov
### Programmer 1: Kazi Hyder
### Programmer 2: Faraj Arvid
### Class period: 10
---
### Proposal: Bubble Shooter Game Recreation in Processing
#### Link to actual game: https://www.bubbleshooter.net/
#### This is a game where you shoot colored balls in a line and the ball with attach itself to the first ball it touches. The ball stays in place on the grid but the rows move down every few moves. You can remove balls if 3 balls of the same color touch eachother. The game will end once a ball reached the bottom of the playing screen. You get points based on how many balls you removed. There are six colors (red, blue, teal, pink, yellow, and green). When the rows shift down, a new row of balls will spawn at the top row and their colors are determined randomly. You can see what color ball you are shooting. The ball you are shooting can also bounce off the wall. If there are any balls that are not attached to the main body of balls anymore, the ball drops and pops, which will count to your score. Combos of higher ball-popping in one move will give more points than a normal move that pops 3 balls.

---
### Ideas That Will Be Used From This Class
#### -Mouse input
#### -Classes
#### -Grids and arrays
#### -Loops, conditionals, and more
---
### Potential Classes:
#### Grid: A grid that shifts .5 space every line, so it is like a hexagonal grid.
####      - Uses elements of the grid class from brick breaker.
#### Bubbles: Class for the bubbles that will go on the grid
#### BubbleShooter: The mechanism at the bottom that shoots the ball in slot and places it at the location where the arrow points unless there are other balls in the way.
#### Arrow: design of the arrow that is fixated at the bottom and rotates the arrow to follow the mouse.
---
### List of Concepts 
#### -Arrays and Grids: Will be implemented to arrange all the bubbles.
#### -Loops and Conditionals: Will be used to create the collision detection.
#### -Collision Detection: Will be used to pop bubbles and make the bubbles interact.
#### -Color Randomization: Will be utilzied to randomize the color of the bubbles.
#### -Counter to keep track of your current score and your personal best. Each bubble that you pop will give 30 points, so popping 3 bubbles will give 90 bubbles. But combos give more points for bubbles popped > 3. Each bubble popped after 3 will have 30(# of bubbles popped / 3) or some other system for combos.
---
### How Will User Interact With the Program 
#### The user will use the mouse to point the bubble shooter (the bubble shooter will shoot out a bubble which is a random color, but you can see the color at the base of the arrow) at a specific colored bubble. The bubble shot out will follow the direction of the arrow, which is based of the mouse_X coordinate. Once the user clicks the mouse, the bubble shooter will fire a bubble in whichever direction the user pointed the shooter at.
---
### Mock-UP

#### ![image](https://user-images.githubusercontent.com/69363132/170043578-52d2d713-a193-4014-9ab0-6fd7ebb9bdbf.png)

